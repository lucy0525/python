from .qa import bp as qa_bp
from .user import bp as user_bp