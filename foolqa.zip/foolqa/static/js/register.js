function bindCaptchaBtnClick() {
    $('#captcha-btn').on("click", function (event) {
        var $this = $(this);
        var email = $("input[name='email']").val();
        if (!email) {
            alert("请先输入邮箱！");
            return;
        }
        // 通过 js 发送网络请求：ajax
        $.ajax({
            url: "/user/captcha",
            method: "POST",
            data: {
                "email": email
            },
            success: function (res) {
                var code = res["code"];
                if (code == 200) {
                    $this.off('click');  // 取消点击事件
                    var countDown = 60;  // 定义倒计时时间
                    var timer = setInterval(function (){  // 定义计时器函数：每 timeout 毫秒重新执行一次 handler
                        countDown -= 1;
                        if (countDown > 0){
                            $this.text(countDown + "秒后重新发送");
                        }else {
                            $this.text("获取验证码");
                            bindCaptchaBtnClick();  // 倒计时结束，重新执行点击事件函数
                            clearInterval(timer)  // 倒计时结束，清除计时器函数
                        }
                    }, 1000);  // 设置每过 1000 毫秒刷新按钮上的文本
                    alert('验证码发送成功！')
                } else {
                    alert(res['message'])
                }
            }
        })
    });
}

// 等网页所有元素都加载完成后再执行
$(function () {
    bindCaptchaBtnClick()
})